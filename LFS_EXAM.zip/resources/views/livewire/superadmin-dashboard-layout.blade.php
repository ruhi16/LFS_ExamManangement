{{-- <livewire:s-a-side-bar-component>

    <h1>SuperAdmin SideBar </h1>

</livewire:s-a-side-bar-component>

<livewire:footer-component /> --}}
{{-- {{ $sabody }} --}}

{{-- This is the end part where unnamed slot will be attached  --}}
