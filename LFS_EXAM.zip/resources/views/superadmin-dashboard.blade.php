
<x-app-layout>
    @section('header')
            <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
                {{-- {{ 'Dashboard: ' . __(auth()->user()->role->name) . ': ' . __(auth()->user()->teacher->id).'-' . __(auth()->user()->teacher->name).' (User Name: '.__(auth()->user()->name).')' }} --}}
                {{ 'Super Admin Dashboard: ' . __('Role-').__(auth()->user()->role->description) . ': ' . __(auth()->user()->id).'-' . __(auth()->user()->name) }}
            </h2>
            
            {{-- {{ $slot  }} --}}            
            

            @yield('component_name') 
        @endsection

    
    {{-- <livewire:s-a-side-bar-component /> --}}
    
        
    {{-- <livewire:footer-component/> --}}

</x-app-layout>







