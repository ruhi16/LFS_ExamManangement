

<x-notice-board
    title="School Notices"
    :notices="$notices"
    
/>

<!-- hello -->
<!-- {{ $notices }} -->