<?php

namespace App\Http\Controllers;

use App\Models\Studentdb;
use Illuminate\Http\Request;

class StudentdbController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Studentdb  $studentdb
     * @return \Illuminate\Http\Response
     */
    public function show(Studentdb $studentdb)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Studentdb  $studentdb
     * @return \Illuminate\Http\Response
     */
    public function edit(Studentdb $studentdb)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Studentdb  $studentdb
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Studentdb $studentdb)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Studentdb  $studentdb
     * @return \Illuminate\Http\Response
     */
    public function destroy(Studentdb $studentdb)
    {
        //
    }
}
