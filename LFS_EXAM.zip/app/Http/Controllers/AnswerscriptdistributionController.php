<?php

namespace App\Http\Controllers;

use App\Models\Answerscriptdistribution;
use Illuminate\Http\Request;

class AnswerscriptdistributionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Answerscriptdistribution  $answerscriptdistribution
     * @return \Illuminate\Http\Response
     */
    public function show(Answerscriptdistribution $answerscriptdistribution)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Answerscriptdistribution  $answerscriptdistribution
     * @return \Illuminate\Http\Response
     */
    public function edit(Answerscriptdistribution $answerscriptdistribution)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Answerscriptdistribution  $answerscriptdistribution
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Answerscriptdistribution $answerscriptdistribution)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Answerscriptdistribution  $answerscriptdistribution
     * @return \Illuminate\Http\Response
     */
    public function destroy(Answerscriptdistribution $answerscriptdistribution)
    {
        //
    }
}
