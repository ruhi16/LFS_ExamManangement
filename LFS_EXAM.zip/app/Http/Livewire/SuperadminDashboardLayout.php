<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SuperadminDashboardLayout extends Component
{
    public function render()
    {
        return view('livewire.superadmin-dashboard-layout');
    }
}
