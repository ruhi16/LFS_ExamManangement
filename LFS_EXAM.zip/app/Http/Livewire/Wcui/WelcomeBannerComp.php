<?php

namespace App\Http\Livewire\Wcui;

use Livewire\Component;

class WelcomeBannerComp extends Component
{
    public function render()
    {
        return view('livewire.wcui.welcome-banner-comp');
    }
}
