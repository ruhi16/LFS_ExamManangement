<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AdminTabTwoComponent extends Component
{
    public function render()
    {
        return view('livewire.admin-tab-two-component');
    }
}
